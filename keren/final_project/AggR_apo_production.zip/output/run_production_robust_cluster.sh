#!/bin/bash
#SBATCH --account=robustelli 
#SBATCH --partition=preempt_robust
#SBATCH --mail-user=michelle.garcia.gr@dartmouth.edu
#SBATCH --mail-type=ALL
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=16
#SBATCH --mem-per-cpu=2000mb
#SBATCH --time=7-00:00:00 
#SBATCH --gpus=2 
#SBATCH --nodes=1 
#SBATCH --nodelist=centurion02

module purge
module load cuda/11.6

source /dartfs-hpc/rc/home/0/f006j60/miniconda3/etc/profile.d/conda.sh
conda activate openmm_S24

export OPENMM_CPU_THREADS=${SLURM_CPUS_PER_TASK}

BASE_DIR=/dartfs-hpc/rc/lab/R/RobustelliP/Michelle/keren/ag_keren/AggR_only

python3 $BASE_DIR/Agg_Alone_Amber.py > run_production.log 2>&1

conda deactivate
